package com.hyla.test;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.lori.utils.Utilities;

import io.appium.java_client.AppiumDriver;

public class TestClass {

	public static AppiumDriver driver;
	DesiredCapabilities dCap = new DesiredCapabilities();
	SoftAssert sA = new SoftAssert();
	

	@BeforeTest
	public void initialized() throws MalformedURLException, Exception {

		dCap.setCapability("deviceName", "Google Nexus 5X_Gogs");
		dCap.setCapability("platformName", "Android");
		dCap.setCapability("browserName", "Chrome");
		dCap.setCapability("chromedriverExecutable", "D:/Appium/chromedriver_win32/chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setExperimentalOption("w3c", false);
//		Map<String, Object> prefs = new HashMap<String, Object>();
//		prefs.put("credentials_enable_service", false);
//		prefs.put("profile.password_manager_enabled", false);
//		chromeOptions.setExperimentalOption("prefs", prefs);
		dCap.merge(chromeOptions);
		driver = new AppiumDriver(new URL("http://127.0.0.1:4723/wd/hub"), dCap);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://hyla.staging.hellolori.com");
		System.out.println("App launched");
	}

	@Test
	public void login() throws Exception {
		Robot robot = new Robot();
		sA.assertEquals(driver.getTitle(),"Lori: Smart(er) Phone Protection","Title didn't match");
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("test-lori-hyla-2@hylamobile.com");

		System.out.println("INFO : Username has been entered");

		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("Hylamobile1@");
		System.out.println("INFO : Password has been entered");

		WebElement signInButton = driver.findElement(By.xpath("//button[contains(text(),'Sign In')]"));
		signInButton.click();
		System.out.println("INFO : SignButton has been clicked");

//		Thread.sleep(10000);

		Utilities.waitForElementToBeiInVisible(driver.findElement(By.xpath("//div[@role='progressbar']")));
		System.out.println("Landed on homepage");
		WebElement scheduleRepairButton = driver.findElement(By.id("scheduleRepair"));

		sA.assertEquals(driver	
				.findElement(By
						.xpath("//div[@class='ProgramBanner_banner__1VY6F false' and contains(text(),'HYLA Mobile Employee Device Protection Program')]"))
				.getText(), "HYLA Mobile Employee Device Protection Program", "Program Name didn't matched");

		Utilities.waitForElementToBeClickable(scheduleRepairButton);
		scheduleRepairButton.click();
		System.out.println("INFO : Schedule Repair button has been clicked");

		WebElement issueType = driver.findElement(
				By.xpath("//div[text()='Select Issues *']/following::input[contains(@id,'react-select-')]"));

		issueType.sendKeys("Charging Port Repair");
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		System.out.println("INFO : Issue type selected");

		WebElement dateOfIncident = driver.findElement(By.xpath("//input[@id='dateOfIncident']"));
		dateOfIncident.sendKeys("03/13/2020");
		
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		System.out.println("INFO : Date of incident selected");

		WebElement descriptionOfIssue = driver.findElement(By.id("notes"));
		descriptionOfIssue.click();
		descriptionOfIssue.sendKeys("Test");

		System.out.println("INFO : Desciption inserted");

		WebElement nextButton1 = driver.findElement(By.xpath("//button[@id='submit']"));
		nextButton1.click();
		System.out.println("INFO : First next button clicked");

		WebElement emailRadioButton = driver.findElement(By.xpath("//input[@value='email']"));
		Utilities.waitForElementToBeiInVisible(nextButton1);
		emailRadioButton.click();
		System.out.println("INFO : Email Radio button clicked");

		WebElement nextButton2 = driver.findElement(By.xpath("//button[contains(text(),'Next')]"));
		nextButton2.click();
		System.out.println("INFO : Second next button clicked");

		WebElement address1 = driver.findElement(By.xpath("//input[@id='streetAddress1']"));
		Utilities.waitForElementToBeiInVisible(nextButton2);
		address1.sendKeys("3729  Dogwood Lane");
		System.out.println("INFO : Address has been entered");

		WebElement cityDetail = driver.findElement(By.xpath("//input[@id='city']"));
		cityDetail.sendKeys("Seattle");
		System.out.println("INFO : City has been entered");

		Select listOfState = new Select(
				driver.findElement(By.id("scheduleRepairRequest.scheduleInformation.address.state")));
		listOfState.selectByVisibleText("Washington");

		WebElement zipCode = driver.findElement(By.xpath("//input[@id='zipcode']"));
		zipCode.sendKeys("85634");
		System.out.println("INFO : Zipcode has been entered");

		WebElement locationDesciption = driver.findElement(By.xpath("//input[@id='locationDescription']"));
		locationDesciption.sendKeys("Kia Store");
		System.out.println("INFO : location description has been entered");

		WebElement nextButton3 = driver.findElement(By.xpath("//button[contains(text(),'Next')]"));
		nextButton3.click();
		System.out.println("INFO : Third next button clicked");
		Utilities.waitForElementToBeiInVisible(nextButton3);
//		Thread.sleep(2000);

		List<WebElement> listOfTimeSlot = driver.findElements(By.xpath("//div[@id='timePickerBox']//div"));
		for (WebElement timeSlots : listOfTimeSlot) {
			if (timeSlots.getText().equalsIgnoreCase("05:00 PM")) {
				timeSlots.click();
			} else {
				System.out.println("TimeSlots not available");

			}
		}
		System.out.println(driver.getCurrentUrl());
		WebElement nextButton4 = driver.findElement(By.xpath("//button[contains(@class,'DeviceRepair_button')]"));
		Utilities.waitForClickable(nextButton4);
		nextButton4.click();
		System.out.println("Fourth next button clicked");
		
//		Thread.sleep(5000);

		Utilities.waitForElementToBeiInVisible(nextButton4);
		WebElement confirmAndPay = driver.findElement(By.xpath("//button[contains(.,'Confirm & Pay')]"));
		Utilities.waitForClickable(confirmAndPay);
		confirmAndPay.click();
		System.out.println("INFO : confirm button button clicked");

		driver.switchTo().frame(driver.findElement(By.tagName("iframe")));
		WebElement nameOnCard = driver.findElement(By.id("NameOnCard"));
		nameOnCard.sendKeys("John Smith");
		WebElement cardNumber = driver.findElement(By.id("CardNumber"));
		cardNumber.sendKeys("41111111111111111");

		Select listOfMonth = new Select(driver.findElement(By.id("ExpirationMonth")));
		listOfMonth.selectByVisibleText("January");

		Select listOfYear = new Select(driver.findElement(By.id("ExpirationYear")));
		listOfYear.selectByVisibleText("2027");

		WebElement securityCode = driver.findElement(By.id("SecurityCode"));
		securityCode.sendKeys("3423");

		WebElement billingAddress = driver.findElement(By.id("BillingAddressStreet"));
		billingAddress.sendKeys("307 Chroas");

		WebElement billigZipCode = driver.findElement(By.id("BillingZip"));
		billigZipCode.sendKeys("34235");

		WebElement continueButton = driver.findElement(By.id("ContinueButton"));
		continueButton.click();

		WebElement submitPayment = driver.findElement(By.id("SubmitButton"));
		submitPayment.click();

		driver.switchTo().defaultContent();

		Utilities.waitForElementToBeVisible(By.xpath(
				"//button[@class='ActiveDeviceRepair_buttonOutline__2omMD Button_button__co9Na' and contains(text(),'Cancel')]"));
		System.out.println("Cancel button visible");
		sA.assertAll();
	}

	@AfterTest
	public void teardown() {
		driver.close();
	}
}
