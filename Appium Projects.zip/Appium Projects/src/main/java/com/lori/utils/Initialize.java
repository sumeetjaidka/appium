package com.lori.utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Initialize {
	
	public static AndroidDriver<MobileElement> driver;
	 DesiredCapabilities dCap = new DesiredCapabilities();

	@BeforeTest
	public void initialization()throws MalformedURLException {

 		dCap.setCapability("deviceName", "Google Nexus 5X");
		dCap.setCapability("platformName", "Android");
		dCap.setCapability("platformVersion", "7.1.1");
		dCap.setCapability("automationName", "UiAutomator2");
		dCap.setCapability("appPackage", "com.android.launcher3");
		dCap.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), dCap);
		driver.get("https://hyla.us-east-1.hellolori.com/");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
