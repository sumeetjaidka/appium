package com.lori.pages;

import org.testng.annotations.BeforeTest;

public class LoginPage {
	
	@BeforeTest
	public void utils() {
		
			
	}
	
	

}
